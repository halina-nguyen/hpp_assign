// calculate faculty of n
int faculty(int n);

// print Pascal’s triangle
void print_triang(int rows);