// calculate faculty of n
unsigned long long faculty(unsigned int n);

// print Pascal’s triangle
void print_triang(unsigned int rows);